@extends('layouts.index')
@section('heading', 'Biaya Pendidikan')
@section('page')
    <a href="" class="text-capitalize">Pendaftaran</a>
    <span class="mx-3 fas fa-angle-right"></span>
    <span class="current">Biaya Pendidikan</span>
@endsection
@section('content')

    {{-- Biaya Pendidikan  begin --}}
    <section class="about spad">
        <div class="container">
            <div class="card-title about__text mb-5">
                <div class="row">
                    <div class="col-lg-12 ">
                        <div class="section-informasi pb-4">
                            <h3 class="text-center text-capitalize">biaya pendidikan TA. 2021-2022
                            </h3>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-lg-12">
                        <div class="section-informasi mt-4 mb-4">
                            <h4 class="mb-1">Sistem Pembayaran Biaya Kuliah Mahasiswa/I TA. 2022/2023 </h4>
                            <span>Pembayaran dilakukan setiap awal bulan paling lambat tanggal 10 disetiap
                                bulannya.</span>
                        </div>

                        <ul class="list-group mt-2">
                            <li class="list-group-item ">
                                <table
                                    class="table table-striped table-bordered table-hover table-responsive table-responsive-sm">
                                    <tbody>
                                        <tr text-align="center">
                                            <td rowspan="2">
                                                <strong> Jenjang</strong>
                                            </td>
                                            <td rowspan="2">
                                                <strong>Program Studi</strong>
                                            </td>
                                            <td colspan="8" text-align="center">
                                                <strong>UANG KULIAH TUNGGAL (PER SEMESTER)</strong>
                                            </td>
                                        </tr>
                                        <tr class="column">
                                            <td>
                                                Kelompok I
                                            </td>
                                            <td>
                                                Kelompok II
                                            </td>
                                            <td>
                                                Kelompok III
                                            </td>
                                            <td>
                                                Kelompok IV
                                            </td>
                                            <td>
                                                Kelompok V
                                            </td>
                                            <td>
                                                Kelompok VI
                                            </td>
                                            <td>
                                                Kelompok VII
                                            </td>
                                            <td>
                                                Kelompok VIII
                                            </td>
                                        </tr>
                                        
                                        <tr>
                                            <td> D3  </td>
                                            <td> Teknik Informatika </td>
                                            <td> 500.000 </td>
                                            <td> 1.000.000 </td>
                                            <td> 2.400.000 </td>
                                            <td> 3.000.000 </td>
                                            <td> 3.500.000 </td>
                                            <td> 4.000.000 </td>
                                            <td> 4.500.000 </td>
                                            <td> 5.000.000 </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
    </section>

    {{-- Biaya Pendidikan  end --}}

@endsection
