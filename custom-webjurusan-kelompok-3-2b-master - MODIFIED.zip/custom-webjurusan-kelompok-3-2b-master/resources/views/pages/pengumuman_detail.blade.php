@extends('layouts.index')
@section('heading', 'Pengumuman Kampus')
@section('page')
    <a href="{{ route('home.pengumuman') }}">Pengumuman </a>
    <span class="mx-3 fas fa-angle-right"></span>
    <span class="current">{{ $read->judul_pengumuman }} </span>
@endsection
@section('content')
    {{-- Pengumuman detail begin --}}
    <section class="about spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-6">
                    <div class="card-title about__text mb-5">
                        <div class="pengumuman">
                            <h4 class="text-center">{{ $read->judul_pengumuman }}</h4>
                            <ul class="list-inline text-center">
                                <li class="list-inline-item text-grey"> <b>Post:</b>
                                    @if ($read->user_id == 1)
                                        BAAK
                                    @elseif ($read->user_id == 2)
                                        KA. Prodi
                                    @else
                                        Kemahasiswaan
                                    @endif
                                </li>
                                <li class="list-inline-item text-grey">Read:
                                    {{ $read->view }}<i class="fab ms-1 fa-readme"></i></li>
                                <li class="list-inline-item text-grey"><i class="fas fa-calendar-week ms-2"></i>
                                    {{ date('d, M Y', strtotime($read->tgl_publish)) }}</li>
                                <li class="list-inline-item text-grey"><i class="fas fa-clock ms-2"></i>
                                    {{ time_elapsed_string($read->created_at) }}</li>
                            </ul>
                            <div class="divider mx-auto mb-4"></div>
                            <h6 class="mb-3"> <span>Catatan: </span>Mohon dibaca hingga selesai apabila pengumuman tersebut penting!</h6>
                            <p>{!! $read->isi !!}</p>
                            <!-- <p>{{ $read->file }}</p> -->
                            <a href="{{ Storage::url($read->file) }}" class="btn btn-success">Unduh</a>
                        </div>
                        <br>
                        <div class="blog_extra d-flex flex-lg-row flex-column align-items-lg-center align-items-start justify-content-start">
                            <div class="blog_social">
                            <span>
                                    Bagikan pengumuman: 
                                    <i class="fas fa-angle-double-right me-2"></i>
                                </span>
                                <ul>
                                    <li>
                                        <a class="whatsapp" href=" https://wa.me/?text={{ url($read->judul_pengumuman) }}" target="_blank">
                                            <i class="fab fa-whatsapp" aria-hidden="true"></i>
                                            WhatsApp
                                        </a>
                                    </li>
                                    <li>
                                        <a class="facebook" href=" https://facebook.com/share.php?u={{ url($read->judul_pengumuman) }}" target="_blank">
                                            <i class="fab fa-facebook" aria-hidden="true"></i>
                                            Facebook
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section>
    {{-- Pengumuman detail  end --}}


@endsection
